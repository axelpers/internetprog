/* jslint node: true */
"use strict";

var express = require('express');
var router = express.Router();
var model = require("./model.js");


router.post('/login', function(req, res){
  console.log('Controller1:',req.body.username);

  // We are using the callback function
  model.checkLogin(req.body.username, function(data){
    var pw = data[0].password;
    if(pw.lenght === 0){
      res.json('Null PW');
    } else if(pw === req.body.password){
      res.json('Success');
    } else {
      res.json('Wrong PW');
    }
  })
});
  // if (data[0].password == req.body.password) {
  //   console.log('Succcyyy')
  //   res.json('Success');
  // } else {
  //   res.json('Login failed')
  // }
  //console.log('Controller2:',data)


module.exports = router;