/* jslint node: true */
"use strict";

var Sequelize = require('sequelize');
var db = new Sequelize('project', 'root', 'root',{
  host: 'localhost',
  port: '8889',
  dialect: 'mysql',
  logging: false
});

exports.checkDB = function (){
  db.authenticate().then(() => {
      console.log('Connection has been established successfully. NICE!');
    })
    .catch(err => {
      console.error('Unable to connect to the database:', err);
    });
}

exports.printMovies = function(){
  db.query("SELECT * FROM Movies",
    {type: db.QueryTypes.SELECT}
  ).then(data =>{
    console.log(data);
  });
}

exports.checkLogin = function(username, callback){
  db.query("SELECT password FROM users WHERE username = :username",
    {replacements: { username: username}, type: db.QueryTypes.SELECT })
    .then(data =>{
      console.log('Model:',data);
      callback(data);
    });
}

exports.createTables = function (){
  // Create movie table
  var Movies = db.define('movies', {
    title: {type: Sequelize.STRING},
    genre: {type: Sequelize.STRING},
    year: {type: Sequelize.INTEGER},
    streamedBy: {type: Sequelize.STRING}
  });
  // Fill movie table
  // force: true will drop the table if it already exists
  Movies.sync({force: true}).then(() => {
    return Movies.bulkCreate([
      {title: 'Nightcrawler', genre: 'Thriller', year: '2014',streamedBy: 'Netflix'},
      {title: 'Kung Fu Panda', genre: 'Barn', year: '2008',streamedBy: 'CMORE'},
      {title: 'Wall Street', genre: 'Drama', year: '1987',streamedBy: 'Buy it'},
      {title: 'The Town', genre: 'Crime', year: '2010',streamedBy: 'Netflix'},
      {title: 'Trettioåriga kriget', genre: 'Historia', year: '2018',streamedBy: 'SVT Play'}
    ]);
  });
  // Create user table
  var Users = db.define('users', {
    username: {type: Sequelize.STRING},
    password: {type: Sequelize.STRING},
    email: {type: Sequelize.STRING}
  });
  // force: true will drop the table if it already exists
  Users.sync({force: true}).then(() => {
    // Table created
    return Users.bulkCreate([
      {username: 'Axel', password: 'password', email: 'axel@mail.com'},
      {username: 'Viktor', password: 'password', email: 'viktor@mail.com'}
    ]);
  });
  // Create rating table
  var Rating = db.define('rating', {
    username: {type: Sequelize.STRING},
    title: {type: Sequelize.STRING},
    rating: {type: Sequelize.INTEGER}
  });
  // force: true will drop the table if it already exists
  Rating.sync({force: true}).then(() => {
    // Table created
    return Rating.bulkCreate([
      {username: 'Axel', title: 'Nightcrawler', rating: '7'},
      {username: 'Viktor', title: 'Wall Street', rating: '10'}
    ]);
  });
  // Create watchlist table
  var Watchlist = db.define('watchlist', {
    username: {type: Sequelize.STRING},
    title: {type: Sequelize.STRING}
  });
  // force: true will drop the table if it already exists
  Watchlist.sync({force: true}).then(() => {
    // Table created
    return Watchlist.bulkCreate([
      {username: 'Axel', title: 'Trettioåriga kriget'},
      {username: 'Viktor', title: 'Nightcrawler'}
    ]);
  });
}



